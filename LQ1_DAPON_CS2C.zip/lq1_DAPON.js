let Name = "Las Marias,Maria Delos Santos";
let Age = 25;
let Add = "Upper Session road, Baguio city, Benguet";

let lName = "Name: ";
let lage = "Age: ";
let ladd = "Address: ";

let combi = lName+Name+", "+lage+Age+", "+ladd+Add;
console.log(combi);

let pName = "Dela Cruz,Juan Gamoso";
let pAge = 28;
let pAdd = "San Nicolas, Candon City, Ilocos Sur";

let lpName = "Name: ";
let lpage = "Age: ";
let lpadd = "Address: ";

let combine = lpName+pName+", "+lpage+pAge+", "+lpadd+pAdd;
console.log(combine);

let store= Name.length+pName.length+Add.length+pAdd.length+Age+pAge;
console.log(store);

let add = Age + pAge;
console.log(add);
let sum = add - Name.length
console.log(sum);
let mup = sum * pName.length;
console.log(mup);
let summ = Add.length ** pAdd.length;
console.log(summ);